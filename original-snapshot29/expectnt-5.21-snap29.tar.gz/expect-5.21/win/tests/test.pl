#! perl

print "This is perl.  You will be assimilated.\n";

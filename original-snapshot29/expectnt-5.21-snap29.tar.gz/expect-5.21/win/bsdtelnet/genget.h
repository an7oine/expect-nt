int isprefix(const char *, const char *);
char **genget(const char *, char **, int);

#define AMBIGUOUS ((void *)1)
#define HELP ((void *)2)

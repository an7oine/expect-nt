extern int getopt	_ANSI_ARGS_(int argc,char **nargv, char *ostr));

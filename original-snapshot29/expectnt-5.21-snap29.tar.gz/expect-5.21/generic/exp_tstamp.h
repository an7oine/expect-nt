EXTERN void		exp_timestamp _ANSI_ARGS_((Tcl_Interp *,time_t *,
				char *));

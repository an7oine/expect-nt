extern int optind;
extern char *optarg;
extern int getopt	(int argc,char **nargv, char *ostr);

/* calc.h.  Generated automatically by configure.  */
/*
 * Check for headers
 */
#ifndef __CALC_H__
#define __CALC_H__

/* #undef HAVE_STDLIB_H */

/*
 * Check for functions
 */
#define HAVE_STRCMP 1

#define NWORD 10
#define SIZE 100
#define VERSION "1.0 Beta"

#endif	/* __CALC_H__ */

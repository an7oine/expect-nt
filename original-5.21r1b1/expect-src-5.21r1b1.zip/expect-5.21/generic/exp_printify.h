#ifndef __EXP_PRINTIFY_H__
#define __EXP_PRINTIFY_H__

char *exp_printify();

#endif /* __EXP_PRINTIFY_H__ */
